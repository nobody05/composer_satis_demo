# zend-servicemanager

The Service Locator design pattern is implemented by the `Zend\ServiceManager`
component. The Service Locator is a service/object locator, tasked with
retrieving other objects.


- File issues at https://github.com/zendframework/zend-servicemanager/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-servicemanager

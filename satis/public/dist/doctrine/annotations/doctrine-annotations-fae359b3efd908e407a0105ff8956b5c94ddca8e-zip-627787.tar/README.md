# Doctrine Annotations

Docblock Annotations Parser library (extracted from Doctrine Common).

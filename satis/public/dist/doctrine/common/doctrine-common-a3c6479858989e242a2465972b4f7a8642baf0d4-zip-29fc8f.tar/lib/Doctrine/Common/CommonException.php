<?php
namespace Doctrine\Common;

/**
 * Base exception class for package Doctrine\Common.
 *
 * @author heinrich
 *
 * @deprecated The doctrine/common package is deprecated, please use specific packages and their exceptions instead.
 */
class CommonException extends \Exception
{
}

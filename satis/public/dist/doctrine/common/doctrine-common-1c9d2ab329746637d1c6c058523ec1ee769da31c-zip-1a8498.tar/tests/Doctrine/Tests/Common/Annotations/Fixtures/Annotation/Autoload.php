<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures\Annotation;

/**
 * @Annotation
 */
class Autoload extends \Doctrine\Common\Annotations\Annotation
{
    
}
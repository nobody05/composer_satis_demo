<?php

use Doctrine\Common\Annotations\Annotation;

class TopLevelAnnotation extends Annotation
{
}

# Doctrine Collections

Collections Abstraction library

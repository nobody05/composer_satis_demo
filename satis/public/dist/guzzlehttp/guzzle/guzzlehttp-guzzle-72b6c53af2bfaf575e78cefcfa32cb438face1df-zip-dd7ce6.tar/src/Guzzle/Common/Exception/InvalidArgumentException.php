<?php

namespace Guzzle\Common\Exception;

use Guzzle\Common\GuzzleException;

class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException {}

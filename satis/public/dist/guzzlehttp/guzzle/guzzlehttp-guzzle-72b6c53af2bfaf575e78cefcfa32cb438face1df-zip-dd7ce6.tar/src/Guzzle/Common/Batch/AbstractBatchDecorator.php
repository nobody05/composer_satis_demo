<?php

namespace Guzzle\Common\Batch;

/**
 * Abstract decorator used when decorating a BatchInterface
 */
abstract class AbstractBatchDecorator implements BatchInterface
{
    /**
     * @var BatchInterface Decorated batch object
     */
    protected $decoratedBatch;

    /**
     * Create the decorator
     *
     * @param BatchInterface $decoratedBatch  BatchInterface that is being decorated
     */
    public function __construct(BatchInterface $decoratedBatch)
    {
        $this->decoratedBatch = $decoratedBatch;
    }

    /**
     * Allow decorators to implement custom methods
     *
     * @param string $method Missing method name
     * @param array  $args   Method arguments
     *
     * @return mixed
     * @codeCoverageIgnore
     */
    public function __call($method, array $args = null)
    {
        return call_user_func_array(array($this->decoratedBatch, $method), $args);
    }

    /**
     * {@inheritdoc}
     */
    public function add($item)
    {
        $this->decoratedBatch->add($item);

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function flush()
    {
        return $this->decoratedBatch->flush();
    }

    /**
     * Get the total number of items in the queue
     *
     * @return int
     */
    public function count()
    {
        return count($this->decoratedBatch);
    }

    /**
     * Trace the decorators associated with the batch
     *
     * @return array
     */
    public function getDecorators(array $found = array())
    {
        $found[] = $this;
        if (method_exists($this->decoratedBatch, 'getDecorators')) {
            return $this->decoratedBatch->getDecorators($found);
        }

        return $found;
    }
}

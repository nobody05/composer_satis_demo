<?php

namespace Guzzle\Tests\Parser\Cookie;

/**
 * @covers Guzzle\Parser\Cookie\CookieParser
 */
class CookieParserTest extends CookieParserProvider
{
    protected $cookieParserClass = 'Guzzle\Parser\Cookie\CookieParser';
}

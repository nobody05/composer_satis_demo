<?php

namespace Guzzle\Tests\Common\Mock;

/**
 * @author Michael Dowling <michael@guzzlephp.org>
 */
class MockSubject extends \Guzzle\Common\Event\AbstractSubject
{
}
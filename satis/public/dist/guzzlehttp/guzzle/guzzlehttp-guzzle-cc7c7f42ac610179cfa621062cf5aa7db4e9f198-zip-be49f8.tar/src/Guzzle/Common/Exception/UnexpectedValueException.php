<?php

namespace Guzzle\Common\Exception;

use Guzzle\Common\GuzzleException;

class UnexpectedValueException extends \UnexpectedValueException implements GuzzleException {}

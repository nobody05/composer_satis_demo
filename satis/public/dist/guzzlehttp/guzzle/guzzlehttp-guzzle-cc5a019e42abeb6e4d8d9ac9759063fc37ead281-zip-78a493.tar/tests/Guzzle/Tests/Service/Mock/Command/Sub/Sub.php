<?php

namespace Guzzle\Tests\Service\Mock\Command\Sub;

use Guzzle\Tests\Service\Mock\Command\MockCommand;

/**
 * Sub folder command
 */
class Sub extends MockCommand
{
}

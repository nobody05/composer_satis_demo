<?php

namespace Guzzle\Common\Exception;

use Guzzle\Common\GuzzleException;

class RuntimeException extends \RuntimeException implements GuzzleException {}

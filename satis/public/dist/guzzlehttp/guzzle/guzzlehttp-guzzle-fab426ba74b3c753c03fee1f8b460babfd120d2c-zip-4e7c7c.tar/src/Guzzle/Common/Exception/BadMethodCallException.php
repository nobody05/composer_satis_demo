<?php

namespace Guzzle\Common\Exception;

use Guzzle\Common\GuzzleException;

class BadMethodCallException extends \BadMethodCallException implements GuzzleException {}

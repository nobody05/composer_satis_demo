<?php

namespace Guzzle\Common;

/**
 * Guzzle exception
 */
interface GuzzleExceptionInterface
{
}
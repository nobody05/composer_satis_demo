<?php

namespace Guzzle\Http;

/**
 * Http exception
 */
class HttpException extends \Exception implements \Guzzle\Common\GuzzleExceptionInterface
{
}
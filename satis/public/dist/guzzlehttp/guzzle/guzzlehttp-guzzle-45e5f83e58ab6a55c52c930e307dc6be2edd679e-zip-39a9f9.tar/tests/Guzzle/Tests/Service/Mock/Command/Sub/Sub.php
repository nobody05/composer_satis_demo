<?php

namespace Guzzle\Tests\Service\Mock\Command\Sub;

use Guzzle\Tests\Service\Mock\Command\MockCommand;

/**
 * Sub folder command
 *
 * @author Michael Dowling <michael@guzzlephp.org>
 */
class Sub extends MockCommand
{
}
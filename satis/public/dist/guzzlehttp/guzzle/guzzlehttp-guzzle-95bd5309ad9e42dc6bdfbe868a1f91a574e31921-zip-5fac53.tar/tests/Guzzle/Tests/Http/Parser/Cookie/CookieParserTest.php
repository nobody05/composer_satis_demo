<?php

namespace Guzzle\Tests\Http\Parser\Cookie;

/**
 * @covers Guzzle\Http\Parser\Cookie\CookieParser
 */
class CookieParserTest extends CookieParserProvider
{
    protected $cookieParserClass = 'Guzzle\Http\Parser\Cookie\CookieParser';
}

<?php

namespace Guzzle\Log;

/**
 * @deprecated
 */
class MonologLogAdapter extends PsrLogAdapter
{
}

<?php

namespace Guzzle\Http;

use Guzzle\Common\GuzzleException;

/**
 * Http exception interface
 */
interface HttpException extends GuzzleException {}

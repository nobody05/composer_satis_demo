<?php

namespace Guzzle\Service\Exception;

class ClientNotFoundException extends ServiceBuilderException {};

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased

For a full diff see [`2.8.1...main`][2.8.1...main].

## [`2.8.1`][2.8.1]

For a full diff see [`2.8.0...2.8.1`][2.8.0...2.8.1].

### Changed

* Dropped support for PHP 7.1 ([#529]), by [@localheinz]

## [`2.8.0`][2.8.0]

For a full diff see [`2.7.0...2.8.0`][2.7.0...2.8.0].

### Changed

* Updated `schema.json` ([#526]), by [@ergebnis-bot]

## [`2.7.0`][2.7.0]

For a full diff see [`2.6.1...2.7.0`][2.6.1...2.7.0].

### Added

* Added `--no-check-lock` option which allows skipping validation of `composer.lock` ([#515]), by [@localheinz]

### Changed

* Updated `schema.json` ([#512]), by [@ergebnis-bot]

## [`2.6.1`][2.6.1]

For a full diff see [`2.6.0...2.6.1`][2.6.0...2.6.1].

### Fixed

* Added support for PHP 8.0, for real ([#484], [#485], [#487]), by [@dependabot]

## [`2.6.0`][2.6.0]

For a full diff see [`2.5.2...2.6.0`][2.5.2...2.6.0].

### Added

* Added support for PHP 8.0 ([#465]), by [@core23]

## [`2.5.2`][2.5.2]

For a full diff see [`2.5.1...2.5.2`][2.5.1...2.5.2].

### Fixed

* Started ignoring platform requirements when updating the lock file ([#481]), by [@localheinz]

## [`2.5.1`][2.5.1]

For a full diff see [`2.5.0...2.5.1`][2.5.0...2.5.1].

### Fixed

* Started updating lock files with a new `Composer\Console\Application` instead of reusing the current instance ([#420]), by [@localheinz]
* Stopped using the deprecated `--no-suggest` option when updating the lock file ([#422]), by [@localheinz]
* Started relaxing schema in place to avoid issues resolving references and the like on Windows ([#424]), by [@localheinz]

## [`2.5.0`][2.5.0]

For a full diff see [`2.4.0...2.5.0`][2.4.0...2.5.0].

### Changed

* Apply lax validation to `composer.json` ([#416]), by [@localheinz]

## [`2.4.0`][2.4.0]

For a full diff see [`2.3.2...2.4.0`][2.3.2...2.4.0].

### Changed

* Started showing validation error messages as obtained from validation instead of relying on on executing composer validate ([#406]), by [@localheinz]
* Made plugin compatible with `composer/composer:^2.0.0`  ([#412]), by [@localheinz]

## [`2.3.2`][2.3.2]

For a full diff see [`2.3.1...2.3.2`][2.3.1...2.3.2].

### Fixed

* Fixed a reference that prevented an upload of release assets ([#380]), by [@localheinz]

## [`2.3.1`][2.3.1]

For a full diff see [`2.3.0...2.3.1`][2.3.0...2.3.1].

### Fixed

* Updated `composer/composer` ([#379]), by [@localheinz]

## [`2.3.0`][2.3.0]

For a full diff see [`2.2.4...2.3.0`][2.2.4...2.3.0].

### Changed

* Updated `schema.json` ([#374]), by [@ergebnis-bot]

## [`2.2.4`][2.2.4]

For a full diff see [`2.2.3...2.2.4`][2.2.3...2.2.4].

### Fixed

* Use real path to `schema.json` ([#364]), by [@localheinz]

## [`2.2.3`][2.2.3]

For a full diff see [`2.2.2...2.2.3`][2.2.2...2.2.3].

### Changed

* Updated `schema.json` ([#354]), by [@ergebnis-bot]

## [`2.2.2`][2.2.2]

For a full diff see [`2.2.1...2.2.2`][2.2.1...2.2.2].

### Changed

* Updated `schema.json` ([#322]), by [@localheinz]

## [`2.2.1`][2.2.1]

For a full diff see [`2.2.0...2.2.1`][2.2.0...2.2.1].

### Changed

* Removed dependency on `ergebnis/composer-json-normalizer` ([#316]), by [@localheinz]

## [`2.2.0`][2.2.0]

For a full diff see [`2.1.2...2.2.0`][2.1.2...2.2.0].

### Added

* Added `--diff` option ([#303]), by [@localheinz]

## [`2.1.2`][2.1.2]

For a full diff see [`2.1.1...2.1.2`][2.1.1...2.1.2].

### Fixed

* Allow passing argument and options to the command ([#301]), by [@localheinz]

## [`2.1.1`][2.1.1]

For a full diff see [`2.1.0...2.1.1`][2.1.0...2.1.1].

### Fixed

* Actually run `composer validate` to show validation errors when `composer.json` is not valid according to its schema ([#297]), by [@localheinz]

## [`2.1.0`][2.1.0]

For a full diff see [`2.0.2...2.1.0`][2.0.2...2.1.0].

### Added

* Started compiling, signing, and uploading `composer-normalize.phar` and `composer-normalize.phar.asc` to release assets when a tag is pushed ([#292]), by [@localheinz]

## [`2.0.2`][2.0.2]

For a full diff see [`2.0.1...2.0.2`][2.0.1...2.0.2].

### Fixed

* Brought back support for PHP 7.1 ([#280]), by [@localheinz]

## [`2.0.1`][2.0.1]

For a full diff see [`2.0.0...2.0.1`][2.0.0...2.0.1]

## Changed

* Removed `Ergebnis\Composer\Normalize\Command\SchemaUriResolver` and checked in `schema.json` instead ([#273]), by [@localheinz]

## [`2.0.0`][2.0.0]

For a full diff see [`1.3.1...2.0.0`][1.3.1...2.0.0].

## Changed

* Started using `ergebnis/composer-json-normalizer` instead of `localheinz/composer-json-normalizer`, `ergebnis/json-normalizer` instead of `localheinz/json-normalizer`, and `ergebnis/json-printer` instead of `localheinz/json-printer` ([#261]), by [@localheinz]
* Removed default values for parameters `$formatter` and `$differ` of constructor of `Ergebnis\Composer\Normalize\Command\NormalizeCommand`  ([#262]), by [@localheinz]
* Renamed vendor namespace `Localheinz` to `Ergebnis` after move to [@ergebnis] ([#267]), by [@localheinz]

  Run

  ```
  $ composer remove localheinz/composer-normalize
  ```

  and

  ```
  $ composer require ergebnis/composer-normalize
  ```

  to update.

  Run

  ```
  $ find . -type f -exec sed -i '.bak' 's/Localheinz\\Composer\\Normalizer/Ergebnis\\Composer\\Normalize/g' {} \;
  ```

  to replace occurrences of `Localheinz\Composer\Normalize` with `Ergebnis\Composer\Normalize`.

  Run

  ```
  $ find -type f -name '*.bak' -delete
  ```

  to delete backup files created in the previous step.
* Marked `Ergebnis\Composer\Normalize\Command\NormalizeCommand` and `Ergebnis\Composer\Normalize\Command\SchemaUriResolver` as internal to allow modifications without the need for major releases ([#270]), by [@localheinz]

### Fixed

* Dropped support for PHP 7.1 ([#235]), by [@localheinz]

## [`1.3.1`][1.3.1]

For a full diff see [`1.3.0...1.3.1`][1.3.0...1.3.1].

### Fixed

* Started using `localheinz/diff` to avoid issues using `sebastian/diff` ([#207]), by [@localheinz]

## [`1.3.0`][1.3.0]

For a full diff see [`1.2.0...1.3.0`][1.2.0...1.3.0].

### Changed

* Resolve local and fall back to remote schema so that command works offline and behind proxies ([#190]), by [@localheinz]

## [`1.2.0`][1.2.0]

For a full diff see [`1.1.4...1.2.0`][1.1.4...1.2.0].

### Changed

* Started using the `StrictUnifiedDiffOutputBuilder` when available to create more condensed diffs when using the `--dry-run` option ([#80]), by [@localheinz]

## [`1.1.4`][1.1.4]

For a full diff see [`1.1.3...1.1.4`][1.1.3...1.1.4].

### Fixed

* Removed requirement for `composer.json` to be writable when using the `--dry-run` option ([#177]), by [@localheinz]

## [`1.1.3`][1.1.3]

For a full diff see [`1.1.2...1.1.3`][1.1.2...1.1.3].

### Fixed

* Reversed use of red and green for rendering diff when using the `--dry-run` option ([#173]), by [@TravisCarden]

## [`1.1.2`][1.1.2]

For a full diff see [`1.1.1...1.1.2`][1.1.1...1.1.2].

### Fixed

* Reverted deprecation of the `file` argument of the `NormalizeCommand` as it turns out that the same functionality can _not_ be achieved using the `--working-dir` option ([#166]), by [@localheinz]

## [`1.1.1`][1.1.1]

For a full diff see [`1.1.0...1.1.1`][1.1.0...1.1.1].

### Removed

* Updated [`localheinz/composer-json-normalizer`](http://github.com/localheinz/composer-json-normalizer), which effectively removed a dependency on [`composer/composer`](https://github.com/composer/composer) ([#157]), by [@localheinz]

## [`1.1.0`][1.1.0]

For a full diff see [`1.0.0...1.1.0`][1.0.0...1.1.0].

### Deprecated

* Deprecated the `file` argument of the `NormalizeCommand` as the same functionality can be achieved using the `--working-dir` option ([#145]), by [@localheinz]

### Fixed

* Force reading `composer.json` and `composer.lock` after normalization to ensure `composer.lock` is updated when not fresh after normalization ([#139]), by [@localheinz]

## [`1.0.0`][1.0.0]

For a full diff see [`0.9.0...1.0.0`][0.9.0...1.0.0].

### Added

* Added this changelog ([#94]), by [@localheinz]

### Removed

* Removed normalizers after extracting package [`localheinz/composer-json-normalizer`](https://github.com/localheinz/composer-json-normalizer) ([#106]), by [@localheinz]

## [`0.9.0`][0.9.0]

For a full diff see [`0.8.0...0.9.0`][0.8.0...0.9.0].

### Changed

* The `ConfigHashNormalizer` now also sorts the `scripts-descriptions` section ([#89]), by [@localheinz]

### Fixed

* When validation of `composer.lock` fails prior to normalization, it is now recommended to update the lock file only ([#86]), by [@svenluijten]

## [`0.8.0`][0.8.0]

For a full diff see [`0.7.0...0.8.0`][0.7.0...0.8.0].

### Changed

* The `ConfigHashNormalizer` now also sorts the `extra` section ([#60]), by [@localheinz]

## [`0.7.0`][0.7.0]

For a full diff see [`0.6.0...0.7.0`][0.6.0...0.7.0].

### Changed

* Updated `localheinz/json-normalizer`, which now sniffs the new-line character and uses it for printing instead of using `PHP_EOL` ([#62]), by [@localheinz]

## [`0.6.0`][0.6.0]

For a full diff see [`0.5.0...0.6.0`][0.5.0...0.6.0].

### Added

* Added a `file` argument to the `NormalizeCommand`, so the path to `composer.json` can be specified now, ([#51]), by [@localheinz]

## [`0.5.0`][0.5.0]

For a full diff see [`0.4.0...0.5.0`][0.4.0...0.5.0].

### Changed

* Updated `localheinz/json-normalizer`, which significantly improves the `SchemaNormalizer` employed to do the major normalization of `composer.json` ([#42]), by [@localheinz]

## [`0.4.0`][0.4.0]

For a full diff see [`0.3.0...0.4.0`][0.3.0...0.4.0].

### Added

* Added `--dry-run` option, which allows usage in Continuous Integration systems, as it renders a diff and exits with a non-zero exit code ([#38]), by [@localheinz]

## [`0.3.0`][0.3.0]

For a full diff see [`0.2.0...0.3.0`][0.2.0...0.3.0].

### Fixed

* Dropped support for PHP 7.0, which allows proper handling of empty PSR-4 namespace prefixes ([#30]), by [@localheinz]

## [`0.2.0`][0.2.0]

For a full diff see [`0.1.0...0.2.0`][0.1.0...0.2.0].

### Added

* Added `--no-update-lock` option, which allows skipping the update of `composer.lock` after normalization ([#28]), by [@localheinz]
* Added the `VersionConstraintNormalizer`, which normalizes version constraints ([#18]), by [@localheinz]

### Fixed

* Using the `--no-scripts` option when invoking the `UpdateCommand` to update `composer.lock` ([#19]), by [@localheinz]

## [`0.1.0`][0.1.0]

For a full diff see [`81bc3a8...0.1.0`][81bc3a8...0.1.0].

### Added

* Added `NormalizeCommand` ([#1]), by [@localheinz]
* Added `ConfigHashNormalizer`, which sorts entries in the `config` section by key ([#2]), by [@localheinz]
* Added the `NormalizePlugin`, which provides the `NormalizeCommand` ([#3]), by [@localheinz]
* Added the `PackageHashNormalizer` which sorts packages in the `conflict`, `provide`, `replaces`, `require`, `require-dev`, and `suggest` sections using the same algorithm that is used by the `sort-packages` option of composer itself ([#6]), by [@localheinz]
* Added the `BinNormalizer`, which sorts entries in the `bin` section by
* Added the `ComposerJsonNormalizer`, which composes all of the above normalizers along with the `SchemaNormalizer`, to normalize `composer.json` according to its underlying JSON schema ([#8] and [#10]), by [@localheinz]

[0.1.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.1.0
[0.2.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.2.0
[0.3.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.3.0
[0.4.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.4.0
[0.5.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.5.0
[0.6.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.6.0
[0.7.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.7.0
[0.8.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.8.0
[0.9.0]: https://github.com/ergebnis/composer-normalize/releases/tag/0.9.0
[1.0.0]: https://github.com/ergebnis/composer-normalize/releases/tag/1.0.0
[1.1.0]: https://github.com/ergebnis/composer-normalize/releases/tag/1.1.0
[1.1.1]: https://github.com/ergebnis/composer-normalize/releases/tag/1.1.1
[1.1.2]: https://github.com/ergebnis/composer-normalize/releases/tag/1.1.2
[1.1.3]: https://github.com/ergebnis/composer-normalize/releases/tag/1.1.3
[1.1.4]: https://github.com/ergebnis/composer-normalize/releases/tag/1.1.4
[1.2.0]: https://github.com/ergebnis/composer-normalize/releases/tag/1.2.0
[1.3.0]: https://github.com/ergebnis/composer-normalize/releases/tag/1.3.0
[1.3.1]: https://github.com/ergebnis/composer-normalize/releases/tag/1.3.1
[2.0.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.0.0
[2.0.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.0.1
[2.0.2]: https://github.com/ergebnis/composer-normalize/releases/tag/2.0.2
[2.1.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.1.0
[2.1.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.1.1
[2.1.2]: https://github.com/ergebnis/composer-normalize/releases/tag/2.1.2
[2.2.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.2.0
[2.2.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.2.1
[2.2.2]: https://github.com/ergebnis/composer-normalize/releases/tag/2.2.2
[2.2.3]: https://github.com/ergebnis/composer-normalize/releases/tag/2.2.3
[2.2.4]: https://github.com/ergebnis/composer-normalize/releases/tag/2.2.4
[2.3.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.3.0
[2.3.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.3.1
[2.3.2]: https://github.com/ergebnis/composer-normalize/releases/tag/2.3.2
[2.4.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.4.0
[2.5.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.5.0
[2.5.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.5.1
[2.5.2]: https://github.com/ergebnis/composer-normalize/releases/tag/2.5.2
[2.6.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.6.0
[2.6.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.6.1
[2.7.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.7.0
[2.8.0]: https://github.com/ergebnis/composer-normalize/releases/tag/2.8.0
[2.8.1]: https://github.com/ergebnis/composer-normalize/releases/tag/2.8.1

[81bc3a8...0.1.0]: https://github.com/ergebnis/composer-normalize/compare/81bc3a8...0.1.0
[0.1.0...0.2.0]: https://github.com/ergebnis/composer-normalize/compare/0.1.0...0.2.0
[0.2.0...0.3.0]: https://github.com/ergebnis/composer-normalize/compare/0.2.0...0.3.0
[0.3.0...0.4.0]: https://github.com/ergebnis/composer-normalize/compare/0.3.0...0.4.0
[0.4.0...0.5.0]: https://github.com/ergebnis/composer-normalize/compare/0.4.0...0.5.0
[0.5.0...0.6.0]: https://github.com/ergebnis/composer-normalize/compare/0.5.0...0.6.0
[0.6.0...0.7.0]: https://github.com/ergebnis/composer-normalize/compare/0.6.0...0.7.0
[0.7.0...0.8.0]: https://github.com/ergebnis/composer-normalize/compare/0.7.0...0.8.0
[0.8.0...0.9.0]: https://github.com/ergebnis/composer-normalize/compare/0.8.0...0.9.0
[0.9.0...1.0.0]: https://github.com/ergebnis/composer-normalize/compare/0.9.0...1.0.0
[1.0.0...1.1.0]: https://github.com/ergebnis/composer-normalize/compare/1.0.0...1.1.0
[1.1.0...1.1.1]: https://github.com/ergebnis/composer-normalize/compare/1.1.0...1.1.1
[1.1.1...1.1.2]: https://github.com/ergebnis/composer-normalize/compare/1.1.1...1.1.2
[1.1.2...1.1.3]: https://github.com/ergebnis/composer-normalize/compare/1.1.2...1.1.3
[1.1.3...1.1.4]: https://github.com/ergebnis/composer-normalize/compare/1.1.3...1.1.4
[1.1.4...1.2.0]: https://github.com/ergebnis/composer-normalize/compare/1.1.4...1.2.0
[1.2.0...1.3.0]: https://github.com/ergebnis/composer-normalize/compare/1.2.0...1.3.0
[1.3.0...1.3.1]: https://github.com/ergebnis/composer-normalize/compare/1.3.0...1.3.1
[1.3.1...2.0.0]: https://github.com/ergebnis/composer-normalize/compare/1.3.1...2.0.0
[2.0.0...2.0.1]: https://github.com/ergebnis/composer-normalize/compare/2.0.0...2.0.1
[2.0.1...2.0.2]: https://github.com/ergebnis/composer-normalize/compare/2.0.1...2.0.2
[2.0.2...2.1.0]: https://github.com/ergebnis/composer-normalize/compare/2.0.2...2.1.0
[2.1.0...2.1.1]: https://github.com/ergebnis/composer-normalize/compare/2.1.0...2.1.1
[2.1.1...2.1.2]: https://github.com/ergebnis/composer-normalize/compare/2.1.1...2.1.2
[2.1.2...2.2.0]: https://github.com/ergebnis/composer-normalize/compare/2.1.2...2.2.0
[2.2.0...2.2.1]: https://github.com/ergebnis/composer-normalize/compare/2.2.0...2.2.1
[2.2.1...2.2.2]: https://github.com/ergebnis/composer-normalize/compare/2.2.1...2.2.2
[2.2.2...2.2.3]: https://github.com/ergebnis/composer-normalize/compare/2.2.2...2.2.3
[2.2.3...2.2.4]: https://github.com/ergebnis/composer-normalize/compare/2.2.3...2.2.4
[2.2.4...2.3.0]: https://github.com/ergebnis/composer-normalize/compare/2.2.4...2.3.0
[2.3.0...2.3.1]: https://github.com/ergebnis/composer-normalize/compare/2.3.0...2.3.1
[2.3.1...2.3.2]: https://github.com/ergebnis/composer-normalize/compare/2.3.1...2.3.2
[2.3.2...2.4.0]: https://github.com/ergebnis/composer-normalize/compare/2.4.0...main
[2.4.0...2.5.0]: https://github.com/ergebnis/composer-normalize/compare/2.4.0...2.5.0
[2.5.0...2.5.1]: https://github.com/ergebnis/composer-normalize/compare/2.5.0...2.5.1
[2.5.1...2.5.2]: https://github.com/ergebnis/composer-normalize/compare/2.5.1...2.5.2
[2.5.2...2.6.0]: https://github.com/ergebnis/composer-normalize/compare/2.5.2...2.6.0
[2.6.0...2.6.1]: https://github.com/ergebnis/composer-normalize/compare/2.6.0...2.6.1
[2.6.1...2.7.0]: https://github.com/ergebnis/composer-normalize/compare/2.6.1...2.7.0
[2.7.0...2.8.0]: https://github.com/ergebnis/composer-normalize/compare/2.7.0...2.8.0
[2.8.0...2.8.1]: https://github.com/ergebnis/composer-normalize/compare/2.8.0...2.8.1
[2.8.1...main]: https://github.com/ergebnis/composer-normalize/compare/2.8.1...main

[#1]: https://github.com/ergebnis/composer-normalize/pull/1
[#2]: https://github.com/ergebnis/composer-normalize/pull/2
[#3]: https://github.com/ergebnis/composer-normalize/pull/3
[#6]: https://github.com/ergebnis/composer-normalize/pull/6
[#8]: https://github.com/ergebnis/composer-normalize/pull/8
[#10]: https://github.com/ergebnis/composer-normalize/pull/10
[#18]: https://github.com/ergebnis/composer-normalize/pull/18
[#19]: https://github.com/ergebnis/composer-normalize/pull/19
[#28]: https://github.com/ergebnis/composer-normalize/pull/28
[#30]: https://github.com/ergebnis/composer-normalize/pull/30
[#38]: https://github.com/ergebnis/composer-normalize/pull/38
[#42]: https://github.com/ergebnis/composer-normalize/pull/42
[#51]: https://github.com/ergebnis/composer-normalize/pull/51
[#60]: https://github.com/ergebnis/composer-normalize/pull/60
[#62]: https://github.com/ergebnis/composer-normalize/pull/62
[#80]: https://github.com/ergebnis/composer-normalize/pull/80
[#86]: https://github.com/ergebnis/composer-normalize/pull/86
[#89]: https://github.com/ergebnis/composer-normalize/pull/89
[#94]: https://github.com/ergebnis/composer-normalize/pull/94
[#106]: https://github.com/ergebnis/composer-normalize/pull/106
[#139]: https://github.com/ergebnis/composer-normalize/pull/139
[#145]: https://github.com/ergebnis/composer-normalize/pull/145
[#157]: https://github.com/ergebnis/composer-normalize/pull/157
[#166]: https://github.com/ergebnis/composer-normalize/pull/166
[#173]: https://github.com/ergebnis/composer-normalize/pull/173
[#177]: https://github.com/ergebnis/composer-normalize/pull/177
[#190]: https://github.com/ergebnis/composer-normalize/pull/190
[#207]: https://github.com/ergebnis/composer-normalize/pull/207
[#235]: https://github.com/ergebnis/composer-normalize/pull/235
[#261]: https://github.com/ergebnis/composer-normalize/pull/261
[#262]: https://github.com/ergebnis/composer-normalize/pull/262
[#267]: https://github.com/ergebnis/composer-normalize/pull/267
[#270]: https://github.com/ergebnis/composer-normalize/pull/270
[#273]: https://github.com/ergebnis/composer-normalize/pull/273
[#280]: https://github.com/ergebnis/composer-normalize/pull/280
[#292]: https://github.com/ergebnis/composer-normalize/pull/292
[#297]: https://github.com/ergebnis/composer-normalize/pull/297
[#301]: https://github.com/ergebnis/composer-normalize/pull/301
[#303]: https://github.com/ergebnis/composer-normalize/pull/303
[#316]: https://github.com/ergebnis/composer-normalize/pull/316
[#322]: https://github.com/ergebnis/composer-normalize/pull/322
[#354]: https://github.com/ergebnis/composer-normalize/pull/354
[#364]: https://github.com/ergebnis/composer-normalize/pull/364
[#374]: https://github.com/ergebnis/composer-normalize/pull/374
[#379]: https://github.com/ergebnis/composer-normalize/pull/379
[#380]: https://github.com/ergebnis/composer-normalize/pull/380
[#406]: https://github.com/ergebnis/composer-normalize/pull/406
[#412]: https://github.com/ergebnis/composer-normalize/pull/412
[#416]: https://github.com/ergebnis/composer-normalize/pull/416
[#420]: https://github.com/ergebnis/composer-normalize/pull/420
[#422]: https://github.com/ergebnis/composer-normalize/pull/422
[#424]: https://github.com/ergebnis/composer-normalize/pull/424
[#465]: https://github.com/ergebnis/composer-normalize/pull/465
[#481]: https://github.com/ergebnis/composer-normalize/pull/481
[#484]: https://github.com/ergebnis/composer-normalize/pull/484
[#485]: https://github.com/ergebnis/composer-normalize/pull/485
[#487]: https://github.com/ergebnis/composer-normalize/pull/487
[#512]: https://github.com/ergebnis/composer-normalize/pull/512
[#515]: https://github.com/ergebnis/composer-normalize/pull/515
[#526]: https://github.com/ergebnis/composer-normalize/pull/526
[#529]: https://github.com/ergebnis/composer-normalize/pull/529

[@core23]: https://github.com/core23
[@dependabot]: https://github.com/dependabot
[@ergebnis-bot]: https://github.com/ergebnis-bot
[@ergebnis]: https://github.com/ergebnis
[@localheinz]: https://github.com/localheinz
[@svenluijten]: https://github.com/svenluijten
[@TravisCarden]: https://github.com/TravisCarden

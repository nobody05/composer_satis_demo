<?php
class ClassWithSelfTypeHint
{
    public function foo(self $foo)
    {
    }
}

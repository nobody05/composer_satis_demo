<?php
trait ExampleTrait
{
    public function ohHai()
    {
        return __FUNCTION__;
    }
}

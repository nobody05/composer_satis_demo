[![Build Status](https://travis-ci.org/sebastianbergmann/php-token-stream.svg?branch=master)](https://travis-ci.org/sebastianbergmann/php-token-stream)

# PHP_TokenStream

## Installation

To add this package as a local, per-project dependency to your project, simply add a dependency on `phpunit/php-token-stream` to your project's `composer.json` file. Here is a minimal example of a `composer.json` file that just defines a dependency on PHP_TokenStream:

    {
        "require": {
            "phpunit/php-token-stream": "~1.2"
        }
    }

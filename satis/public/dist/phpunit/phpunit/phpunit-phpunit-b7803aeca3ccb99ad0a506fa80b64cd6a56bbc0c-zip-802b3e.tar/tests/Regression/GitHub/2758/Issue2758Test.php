<?php
class Issue2758Test extends PHPUnit_Framework_TestCase
{
    public function testOne()
    {
    }
}

<?php
class StopsOnWarningTest extends PHPUnit_Framework_TestCase
{
    public function testOne()
    {
    }
}

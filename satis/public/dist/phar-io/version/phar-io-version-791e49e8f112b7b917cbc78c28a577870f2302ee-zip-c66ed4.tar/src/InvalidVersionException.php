<?php
namespace PharIo\Version;

class InvalidVersionException extends \Exception {
}

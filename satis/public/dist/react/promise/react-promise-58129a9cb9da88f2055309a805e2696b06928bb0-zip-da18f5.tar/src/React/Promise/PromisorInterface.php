<?php

namespace React\Promise;

interface PromisorInterface
{
    public function promise();
}

# localheinz/diff

This is a fork of [`sebastian/diff`](https://github.com/sebastianbergmann/diff) for use with [`ergebnis/composer-normalize`](https://github.com/ergebnis/composer-normalize), with permission from Sebastian Bergmann.

Please use [`sebastian/diff`](https://github.com/sebastianbergmann/diff) instead.

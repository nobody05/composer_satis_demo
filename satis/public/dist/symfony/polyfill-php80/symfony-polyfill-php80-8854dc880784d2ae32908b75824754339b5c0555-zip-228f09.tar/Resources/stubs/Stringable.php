<?php

interface Stringable
{
    /**
     * @return string
     */
    public function __toString();
}

<?php

class Error extends Exception
{
}

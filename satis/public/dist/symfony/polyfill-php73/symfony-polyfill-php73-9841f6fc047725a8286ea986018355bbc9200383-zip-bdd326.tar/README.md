Symfony Polyfill / Php73
========================

This component provides functions added to PHP 7.3 core:

- [`is_countable`](https://php.net/is_countable)

More information can be found in the
[main Polyfill README](https://github.com/symfony/polyfill/blob/master/README.md).

License
=======

This library is released under the [MIT license](LICENSE).

<?php

namespace Acme\DemoLib\Lets\Go\Deeper;

class Class_With_Underscores
{
}

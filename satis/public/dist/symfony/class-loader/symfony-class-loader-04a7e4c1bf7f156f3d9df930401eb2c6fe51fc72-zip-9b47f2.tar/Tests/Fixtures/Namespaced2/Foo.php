<?php

namespace Namespaced2;

class Foo
{
    public static $loaded = true;
}

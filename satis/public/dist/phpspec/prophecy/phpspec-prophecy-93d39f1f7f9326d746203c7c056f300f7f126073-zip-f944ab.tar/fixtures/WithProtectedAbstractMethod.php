<?php

namespace Fixtures\Prophecy;

abstract class WithProtectedAbstractMethod
{
    abstract protected function innerDetail();
}

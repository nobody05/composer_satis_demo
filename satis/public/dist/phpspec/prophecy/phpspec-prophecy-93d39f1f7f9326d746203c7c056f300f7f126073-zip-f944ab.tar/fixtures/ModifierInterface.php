<?php

namespace Fixtures\Prophecy;

interface ModifierInterface
{
    public function isAbstract();

    public function getVisibility();
}

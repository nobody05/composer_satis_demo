<?php

namespace Fixtures\Prophecy;

class WithTypehintedVariadicArgument
{
    function methodWithTypeHintedArgs(array ...$args)
    {
    }
}

# ChangeLog

All notable changes are documented in this file using the [Keep a CHANGELOG](https://keepachangelog.com/) principles.

## [4.0.2] - 2020-06-26

### Added

* This component is now supported on PHP 8

## [4.0.1] - 2020-06-15

### Changed

* Tests etc. are now ignored for archive exports

[4.0.2]: https://github.com/sebastianbergmann/recursion-context/compare/4.0.1...4.0.2
[4.0.1]: https://github.com/sebastianbergmann/recursion-context/compare/4.0.0...4.0.1

Changelog
=========

* 1.0.0-beta (2015-03-19)

 * first beta release
